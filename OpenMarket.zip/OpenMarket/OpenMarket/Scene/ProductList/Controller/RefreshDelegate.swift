//
//  RefreshDelegate.swift
//  OpenMarket
//
//  Created by lily on 2022/01/26.
//

import Foundation

protocol RefreshDelegate: AnyObject {
    
    func refresh()
}
