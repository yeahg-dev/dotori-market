//
//  CellType.swift
//  OpenMarket
//
//  Created by lily on 2022/01/28.
//

import Foundation

enum CellType {
    
    case imagePickerCell
    case productImageCell
}
