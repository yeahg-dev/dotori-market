//
//  PrdouctDetailCollectionViewCell.swift
//  OpenMarket
//
//  Created by 1 on 2022/06/09.
//

import UIKit

class PrdouctDetailCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var prdouctImage: UIImageView!
    
    override class func awakeFromNib() {
        super.awakeFromNib()
    }
    
    func update(){
        self.contentView.addSubview(UIView(frame: .zero))
//        prdouctImage.image = UIImage(named: "pencil")
    }
}
