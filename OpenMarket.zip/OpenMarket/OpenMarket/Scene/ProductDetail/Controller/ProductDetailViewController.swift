//
//  ProductDetailViewController.swift
//  OpenMarket
//
//  Created by 1 on 2022/06/08.
//

import UIKit

final class ProductDetailViewController: UIViewController {

    // MARK: - IBOutlet
    @IBOutlet private weak var prductImageCollectionView: UICollectionView?
    @IBOutlet private weak var productName: UILabel?
    @IBOutlet private weak var productPrice: UILabel?
    @IBOutlet private weak var productSellingPrice: UILabel?
    @IBOutlet private weak var discountRate: UILabel?
    @IBOutlet private weak var productDescription: UITextView?
    
    // MARK: - UI Property
//    private let imagePageControl = UIPageControl()
    private let flowLayout = UICollectionViewFlowLayout()
    
    // MARK: - Property
    private let apiService = APIExecutor()
    private var productID: Int?
    private var productDetail: ProductDetail?
    
    // MARK: - View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.configureCollectionView()
//        self.configureCollectionViewFlowLayout()
        self.configureNavigationItem()
//        self.layoutImagePageControl()
        self.downloadProductDetail(prodcutID: productID)
    }
    
    private func configureCollectionView() {
        self.prductImageCollectionView?.register(PrdouctDetailCollectionViewCell.self, forCellWithReuseIdentifier: "PrdouctDetailCollectionViewCell")
        self.prductImageCollectionView?.showsHorizontalScrollIndicator = false
    }

    private func configureCollectionViewFlowLayout() {
        let cellWidth = self.prductImageCollectionView?.bounds.width
        // FIXME: cell 의 height 값에 intrinsic size 를 부여하는 방법을 찾아서 고쳐야 함!
        flowLayout.itemSize = CGSize(width: cellWidth!, height: cellWidth!)
        flowLayout.minimumLineSpacing = 10
        flowLayout.minimumInteritemSpacing = 10
        flowLayout.scrollDirection = .horizontal
        self.prductImageCollectionView?.collectionViewLayout = flowLayout
    }
    
    private func configureNavigationItem() {
        let composeButton = UIBarButtonItem(barButtonSystemItem: .compose, target: nil, action: nil)
        self.navigationItem.setRightBarButton(composeButton, animated: true)
    }
    
//    private func layoutImagePageControl() {
//        self.prductImageCollectionView?.addSubview(imagePageControl)
//        self.imagePageControl.translatesAutoresizingMaskIntoConstraints = false
//        NSLayoutConstraint.activate([
//            self.imagePageControl.centerXAnchor.constraint(
//                equalTo: self.prductImageCollectionView!.centerXAnchor),
//            self.imagePageControl.bottomAnchor.constraint(
//                equalTo: self.prductImageCollectionView!.bottomAnchor)
//        ])
//    }
    
    private func configureNavigationTitle(with title: String) {
        self.navigationItem.title = title
    }

    // MARK: - Method
    func setProduct(_ id: Int) {
        self.productID = id
    }
    
    private func downloadProductDetail(prodcutID: Int?) {
        guard let id = prodcutID else { return }
         
        let request = ProductDetailRequest(productID: id)
        apiService.execute(request) { [weak self] (result: Result<ProductDetail, Error>) in
            switch result {
            case .success(let product):
                DispatchQueue.main.async {
                    self?.updateProdutDetail(with: product)
                }
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
    
    private func updateProdutDetail(with product: ProductDetail) {
        self.configureNavigationTitle(with: product.name)
        self.productName?.text = product.name
        self.productPrice?.text = product.price.description
        self.productSellingPrice?.text = product.bargainPrice.description
        self.productDescription?.text = "상품설명"
        self.prductImageCollectionView?.reloadData()
    }
    
}

extension ProductDetailViewController: UICollectionViewDataSource {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 3
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {

        guard let cell = self.prductImageCollectionView?.dequeueReusableCell(withClass: PrdouctDetailCollectionViewCell.self, for: indexPath) else {
            return PrdouctDetailCollectionViewCell()
        }
        
        // URL이 nil로 올 때 처리
//        let imageURL = productDetail?.images[indexPath.row].thumbnailURL
        cell.update()
        return cell
    }
    
}

extension ProductDetailViewController: UICollectionViewDelegate {
    
}

//extension ProductDetailViewController: UICollectionViewDelegateFlowLayout {
//    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
//        let cellWidth = self.prductImageCollectionView?.bounds.width
//
//        return CGSize(width: cellWidth!, height: cellWidth!)
//    }
//}
