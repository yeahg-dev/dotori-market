//
//  Notification+Extension.swift
//  OpenMarket
//
//  Created by 예거 on 2022/01/25.
//

import Foundation

extension Notification.Name {
    
    static let newProductRegistered = Notification.Name("newProductRegistered")
}
