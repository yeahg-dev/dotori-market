//
//  String+Extension.swift
//  OpenMarket
//
//  Created by 예거 on 2022/01/14.
//

import Foundation

extension String {
    
    static let whiteSpace = " "
    static let empty = ""
}
