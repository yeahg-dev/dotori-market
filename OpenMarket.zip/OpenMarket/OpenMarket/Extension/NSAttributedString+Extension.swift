//
//  NSAttributedString+Extension.swift
//  OpenMarket
//
//  Created by 예거 on 2022/01/14.
//

import Foundation

extension NSAttributedString {
    
    static let whiteSpace = NSAttributedString(string: .whiteSpace)
}
