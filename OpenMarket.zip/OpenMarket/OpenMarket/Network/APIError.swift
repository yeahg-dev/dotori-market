//
//  APIError.swift
//  OpenMarket
//
//  Created by 예거 on 2022/01/06.
//

import Foundation

enum APIError: Error {

    case invalidURL
    case invalidResponseDate
}
